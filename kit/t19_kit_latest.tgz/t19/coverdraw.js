function coverDraw(){const V=H>W,t=15.0;const tint=GRN;const dx=(typeof COVX!=='undefined')?COVX:0,cs=(typeof COVS!=='undefined')?COVS:1;
  // 1) world, dimmed
  stage(t,1.1,V?CX:W*0.7);ctx.save();ctx.globalCompositeOperation='color';ctx.globalAlpha=EP_TA;ctx.fillStyle=EP_TINT;ctx.fillRect(0,0,W,H);ctx.restore();
  const halo2=(x,y,r,a)=>{const g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,`rgba(${tint[0]},${tint[1]},${tint[2]},${a})`);g.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=g;ctx.fillRect(x-r,y-r,2*r,2*r);};
  const fitT=(s,max,wmax)=>Math.min(max,wmax/(s.length*1.04));
  const hook=(x,y,size,align)=>{const w1=TW(DEF1,size,900,SRF,2),w2=TW(DEF2,size,900,SRF,2);const x0=align==='center'?x-(w1+w2)/2:x;T(DEF1,x0+w1/2,y,size,[236,236,240],1,900,SRF,'center',2);
    ctx.save();ctx.shadowColor=`rgba(${tint[0]},${tint[1]},${tint[2]},0.9)`;ctx.shadowBlur=24;T(DEF2,x0+w1+w2/2,y,size,tint,1,900,SRF,'center',2);ctx.restore();};
  const enLine=(x,y,w)=>{ctx.save();ctx.strokeStyle=`rgba(${tint[0]},${tint[1]},${tint[2]},0.6)`;ctx.lineWidth=2;const tw=TW(EN,24,600,LAT,6);ctx.beginPath();ctx.moveTo(x-w/2,y);ctx.lineTo(x-tw/2-24,y);ctx.moveTo(x+tw/2+24,y);ctx.lineTo(x+w/2,y);ctx.stroke();ctx.restore();T(EN,x,y,24,[200,200,210],0.9,600,LAT,'center',6);};
  const bubs=(P)=>{if(typeof Q71==='undefined'||!P||!P.length)return;[0,1].forEach(i=>{const q=Q71[i];if(!q)return;ctx.save();ctx.translate(P[i][0],P[i][1]);ctx.rotate(i?0.03:-0.04);speech(q[0],0,0,1,i?1:-1,1.05);ctx.restore();});};
  if(V){halo2(CX,900,520,0.30);
    mini(CX-dx*1.3*cs,1330,1.3*cs,()=>peak(t));
    bubs((typeof COVB!=='undefined')?COVB:[[CX-250,640],[CX+250,730]]);
    {const g=ctx.createLinearGradient(0,0,0,620);g.addColorStop(0,'rgba(6,6,10,0.88)');g.addColorStop(0.75,'rgba(6,6,10,0.6)');g.addColorStop(1,'rgba(6,6,10,0)');ctx.fillStyle=g;ctx.fillRect(0,0,W,620);}
    brand(CX,70,32,1,'center');
    const ts=fitT(TTL,200,940);ctx.save();ctx.translate(CX,250);lumText(TTL,0,0,ts,t,6);ctx.restore();
    hook(CX,395,fitT(DEF1+DEF2,52,960),'center');enLine(CX,480,760);}
  else{halo2(W*0.7,560,520,0.32);
    mini(W*0.7-dx*1.25*cs,960,1.25*cs,()=>peak(t));
    bubs((typeof COVBH!=='undefined')?COVBH:[[W*0.55,250],[W*0.86,330]]);
    brand(W*0.27,80,28,1,'center');const rx=W*0.27;
    const ts=fitT(TTL,170,620);ctx.save();ctx.translate(rx,420);lumText(TTL,0,0,ts,t,6);ctx.restore();
    const hs=fitT(DEF1,48,620);T(DEF1,rx,580,hs,[236,236,240],1,900,SRF,'center',2);ctx.save();ctx.shadowColor=`rgba(${tint[0]},${tint[1]},${tint[2]},0.9)`;ctx.shadowBlur=24;T(DEF2,rx,665,fitT(DEF2,60,620),tint,1,900,SRF,'center',2);ctx.restore();
    enLine(rx,770,560);}
  window.done=true;}
window.ready.then(()=>coverDraw());
