const _drawStick0=drawStick;
drawStick=function(x,y,s,P,al,t,glow=1){const k=_drawStick0(x,y,s,P,al,t,glow);const M=P.mood;if(!M)return k;
  const c=[x+k.hc[0]*s,y+k.hc[1]*s],r=SK.head*s;const fwd=P.front?0:r*0.22;ctx.save();ctx.globalAlpha*=al;
  {const fr=r-6*s;const fg=ctx.createRadialGradient(c[0],c[1]-fr*0.3,fr*0.1,c[0],c[1],fr);fg.addColorStop(0,'#1e1014');fg.addColorStop(1,'#070204');ctx.fillStyle=fg;ctx.beginPath();ctx.arc(c[0],c[1],fr,0,6.283);ctx.fill();ctx.strokeStyle='rgba(255,255,255,0.25)';ctx.lineWidth=1.5*s;ctx.beginPath();ctx.arc(c[0],c[1],fr-2*s,Math.PI*1.1,Math.PI*1.75);ctx.stroke();}
  const col='rgba(255,240,236,1)';ctx.strokeStyle=col;ctx.fillStyle=col;ctx.shadowColor=rgba(AC,0.6);ctx.shadowBlur=4*s;ctx.lineCap='round';ctx.lineWidth=3.2*s;
  const ex=[c[0]+fwd-r*0.3,c[0]+fwd+r*0.3],ey=c[1]-r*0.08;const cl=M.eyesClosed||0;const blink=((t*0.37)%1)>0.95?1:cl;
  ex.forEach((xx,i)=>{if(blink>0.6){ctx.beginPath();ctx.arc(xx,ey,5*s,0.15*Math.PI,0.85*Math.PI);ctx.stroke();}else{ctx.beginPath();ctx.ellipse(xx,ey,4.3*s,(6.5-3*(M.squint||0))*s,0,0,6.283);ctx.fill();}
    const b=M.brow||0,side=i?1:-1;ctx.beginPath();ctx.moveTo(xx-7*s,ey-12*s+side*b*4*s);ctx.lineTo(xx+7*s,ey-12*s-side*b*4*s);ctx.stroke();});
  const mx=c[0]+fwd,my=c[1]+r*0.4,mw=r*0.36,sm=M.smile||0,op=M.open||0;
  if(op>0.05){ctx.beginPath();ctx.ellipse(mx,my,mw*0.55,mw*0.45*op+2*s,0,0,6.283);ctx.fill();ctx.fillStyle='#04080b';ctx.beginPath();ctx.ellipse(mx,my+1*s,mw*0.38,mw*0.32*op,0,0,6.283);ctx.fill();}
  else{ctx.beginPath();ctx.moveTo(mx-mw,my-sm*4*s);ctx.quadraticCurveTo(mx,my+sm*11*s+(M.wobble?Math.sin(t*40)*1.5*s:0),mx+mw,my-sm*4*s);ctx.stroke();}
  if(M.sweat>0){ctx.fillStyle=`rgba(255,205,195,${M.sweat})`;const sx=c[0]-r*0.95,sy=c[1]-r*0.45+((t*30)%12)*s;ctx.beginPath();ctx.moveTo(sx,sy-9*s);ctx.quadraticCurveTo(sx+7*s,sy+3*s,sx,sy+6*s);ctx.quadraticCurveTo(sx-7*s,sy+3*s,sx,sy-9*s);ctx.fill();}
  ctx.restore();return k;};
