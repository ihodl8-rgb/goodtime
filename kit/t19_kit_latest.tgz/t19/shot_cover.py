import os,pathlib
os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH","/opt/pw-browsers")
from playwright.sync_api import sync_playwright
H=pathlib.Path(__file__).parent
with sync_playwright() as p:
    b=p.chromium.launch()
    for w,h,n in[(1440,1080,'cover_h.png'),(1080,1440,'cover_v.png')]:
        pg=b.new_page(viewport={"width":w,"height":h});pg.goto((H/'cover.html').as_uri()+f"?w={w}&h={h}");pg.wait_for_function("window.done===true")
        pg.screenshot(path=str(H/n))
    b.close()
