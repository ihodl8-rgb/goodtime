#!/bin/bash
# sequential job runner: jobs.txt lines "dir name"; done.txt records finished
J=/home/claude/t19/jobs.txt; D=/home/claude/t19/done.txt; touch $J $D

while true; do
  next=$(grep -vxF -f $D $J | head -1)
  if [ -z "$next" ]; then sleep 15; continue; fi
  set -- $next; /home/claude/t19/full.sh $1 $2 > $1/full.log 2>&1; echo "$next" >> $D
done
