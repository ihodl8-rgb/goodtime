import numpy as np, scipy.io.wavfile as w, scipy.signal as sg, json, sys
P=json.loads(sys.argv[1]); out=sys.argv[2]
SR=44100;BPM=P.get('bpm',120);BT=60/BPM;DUR=P.get('dur',21.0);N=int(SR*DUR)
B0=P.get('b0',0.0);Q0,Q1,OUT=P.get('q0',12.0),P.get('q1',13.5),P.get('out',16.5)
style=P.get('style','house');root=P.get('root',57)
PROG=[[root+i for i in c] for c in P.get('prog',[[0,3,7],[-4,0,3],[-9,-5,-2],[-2,2,5]])]
L=np.zeros(N);R=np.zeros(N);rng=np.random.default_rng(P.get('seed',1))
def add(sig,t0,g=1.0,pan=0.0):
    i=int(t0*SR);j=min(N,i+len(sig))
    if j<=i or i<0:return
    s=sig[:j-i]*g;L[i:j]+=s*np.sqrt(0.5*(1-pan));R[i:j]+=s*np.sqrt(0.5*(1+pan))
def env(n,a,d):t=np.arange(n)/SR;return np.minimum(1,t/max(a,1e-4))*np.exp(-t/d)
def lp(x,fc):b,a=sg.butter(2,min(fc,SR/2-200)/(SR/2));return sg.lfilter(b,a,x)
def hp(x,fc):b,a=sg.butter(2,fc/(SR/2),'high');return sg.lfilter(b,a,x)
mid=lambda m:440*2**((m-69)/12)
def osc(kind,f,n,det=0):
    t=np.arange(n)/SR;out=0
    for d in ([-det,0,det] if det else [0]):
        ph=2*np.pi*f*(1+d)*t
        out=out+(sg.sawtooth(ph) if kind=='saw' else sg.square(ph,0.5) if kind=='sq' else sg.square(ph,0.25) if kind=='pulse' else sg.sawtooth(ph,0.5) if kind=='tri' else np.sin(ph))
    return out/(3 if det else 1)
def kick(dec=6.5):
    n=int(0.45*SR);t=np.arange(n)/SR;f=45+120*np.exp(-t*28);ph=2*np.pi*np.cumsum(f)/SR;return np.sin(ph)*np.exp(-t*dec)
def snare():
    n=int(0.25*SR);x=hp(rng.standard_normal(n),1200);t=np.arange(n)/SR;return x*np.exp(-t*16)*0.8+np.sin(2*np.pi*190*t)*np.exp(-t*30)*0.4
def hat(o=False):
    n=int((0.16 if o else 0.045)*SR);x=hp(rng.standard_normal(n),7000);t=np.arange(n)/SR;return x*np.exp(-t*(13 if o else 75))*0.33
sect=lambda t:'break' if Q0<=t<Q1 else ('drop' if Q1<=t<OUT else ('outro' if t>=OUT else 'main'))
duck=np.ones(N)
nb=int(DUR/BT)+1
for b in range(nb):
    t=B0+b*BT;s=sect(t)
    if s=='break':continue
    if style=='dembow':
        add(kick(7.5),t,1.0 if s!='outro' else 0.8)
        add(snare()*0.9,t+BT*(0.75 if b%2==0 else 0.5),0.5)
        add(hat(),t+BT/2,0.35,0.3);add(hat(),t+BT*0.25,0.18,-0.3)
        if s=='drop': add(hat(True),t+BT*0.75,0.25,0.2)
    elif style=='dnb':
        # breakbeat at double-time feel: kick 1 & 2.5, snare 2 & 4
        if b%4 in (0,): add(kick(),t,0.9)
        if b%4==2: add(kick(),t+BT/2,0.8)
        if b%2==1: add(snare(),t,0.6)
        for k in range(4): add(hat(),t+k*BT/4,0.35,0.3 if k%2 else -0.3)
    elif style=='trap':
        if b%4 in (0,): add(kick(4),t,1.0)
        if b%8==3: add(kick(4),t+BT/2,0.8)
        if b%4==2: add(snare(),t,0.65)
        for k in range(4 if b%4!=3 else 8): add(hat(),t+k*BT/(4 if b%4!=3 else 8),0.3,0.25)
    else:
        add(kick(),t,0.95 if s!='outro' else 0.75)
        if b%2==1: add(snare() if style!='house' else hp(snare(),900),t,0.45 if style!='lofi' else 0.35)
        sw=0.06 if style=='lofi' else 0
        add(hat(),t+BT/2+sw,0.5,0.3)
        if s=='drop' and b%2==1: add(hat(True),t+BT/2,0.45,0.2)
    i=int(t*SR);n=min(int(0.22*SR),N-i)
    if b%(2 if style in('dnb','trap') else 1)==0 and n>0: duck[i:i+n]=np.minimum(duck[i:i+n],1-0.6*np.exp(-np.arange(n)/SR*14))
bk=P.get('bass','saw')
for k in range(int(DUR/(BT/2))):
    t=B0+k*BT/2;s=sect(t)
    if s=='break':continue
    bar=int(t//(4*BT))%len(PROG);f=mid(PROG[bar][0]-12-(12 if style in('dnb','trap') else 0))
    n=int(BT/2*SR*0.95);x=lp(osc(bk,f,n,0.004),900 if s!='drop' else 1500)*env(n,0.004,0.2)
    add(x,t,0.36)
lead=P.get('lead','sq')
for k in range(int(DUR/(BT/4))):
    t=B0+k*BT/4
    if t<2:continue
    s=sect(t);bar=int(t//(4*BT))%len(PROG);ch=PROG[bar];m=ch[k%3]+12+(12 if (k//3)%4==3 else 0)
    n=int(0.12*SR);x=osc(lead,mid(m),n)*env(n,0.002,0.06)
    if style=='8bit':x=np.round(x*4)/4
    g={'main':0.06,'break':0.05,'drop':0.085,'outro':0.05}[s]
    if s=='break':x=lp(x,800+3000*(t-Q0)/(Q1-Q0))
    add(x,t,g,0.4 if k%2 else -0.4)
for bar in range(int(DUR/(4*BT))+1):
    t=B0+bar*4*BT;ch=PROG[bar%len(PROG)];n=int((4*BT+0.05)*SR);x=0
    for m in ch:x=x+osc(P.get('pad','saw'),mid(m),n,0.006)
    tt=np.arange(n)/SR;e=np.minimum(1,tt/0.1)*np.minimum(1,np.maximum(0,(4*BT+0.05-tt))/0.1)
    add(lp(x,1000 if style!='lofi' else 700)*e*0.045,t)
# riser + impact
n=int((Q1-Q0+1.5)*SR);x=rng.standard_normal(n);tt=np.arange(n)/SR;y=np.zeros(n);T=n/SR
for i in range(0,n,2048):
    fc=300+9000*(tt[i]/T)**2;b,a=sg.butter(2,fc/(SR/2));y[i:i+2048]=sg.lfilter(b,a,x[i:i+2048])
add(y*(tt/T)**2*0.35,Q1-T)
n=int(2.5*SR);tt=np.arange(n)/SR;boom=np.sin(2*np.pi*np.cumsum(40+60*np.exp(-tt*6))/SR)*np.exp(-tt*1.6);cr=lp(rng.standard_normal(n),9000)*np.exp(-tt*2.2)*0.25
add(boom*0.9+cr,Q1)
if style=='lofi':
    vin=lp(rng.standard_normal(N),3000)*0.012;L+=vin;R+=vin
gt=np.arange(N)/SR;ge=np.where(gt<Q0,0.72,np.where(gt<Q1,0.72+0.28*(gt-Q0)/(Q1-Q0),1.0))
mL=L*(0.72+0.28*duck)*ge;mR=R*(0.72+0.28*duck)*ge
if style=='lofi':mL=lp(mL,6000);mR=lp(mR,6000)
fo=np.ones(N);m=int(0.6*SR);fo[-m:]=np.linspace(1,0,m)
st=np.stack([mL*fo,mR*fo],1);st/=np.abs(st).max()*1.05
w.write(out,SR,(st*32767).astype(np.int16))
