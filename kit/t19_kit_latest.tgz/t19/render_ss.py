import sys, os, base64, pathlib
from playwright.sync_api import sync_playwright
os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", "/opt/pw-browsers")
HERE = pathlib.Path(__file__).parent
FPS = 30

def render(items, outdir):
    """items: list of (filename, t)"""
    outdir = pathlib.Path(outdir); outdir.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": 2160, "height": 2880})
        pg.goto((HERE / "index_ss.html").as_uri(), timeout=300000)
        import json
        pg.evaluate("window.ready")
        pg.evaluate("tl=>window.setTL(tl)", json.loads((HERE / "timeline.json").read_text()))
        errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        for name, t in items:
            data = pg.evaluate("(t)=>{window.draw(t);return document.getElementById('c').toDataURL('image/png')}", t)
            (outdir / name).write_bytes(base64.b64decode(data.split(",", 1)[1]))
        if errs: print("PAGE ERRORS:", errs[:3])
        b.close()

if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "keys":   # keys "t1,t2,..." outdir
        ts = [float(x) for x in sys.argv[2].split(",")]
        render([(f"k{i:02d}_{t:07.3f}.png", t) for i, t in enumerate(ts)], sys.argv[3])
    else:                # full start_frame end_frame outdir
        a, b = int(sys.argv[2]), int(sys.argv[3])
        render([(f"f{i:05d}.png", i / FPS) for i in range(a, b)], sys.argv[4])
