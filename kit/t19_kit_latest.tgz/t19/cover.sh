#!/bin/bash
cd $1; python3 - <<P
h=open('index.html').read().replace("const W=1080,H=1440;const cv","const _q=new URLSearchParams(location.search);const W=+(_q.get('w')||1080),H=+(_q.get('h')||1440);document.getElementById('c').width=W;document.getElementById('c').height=H;const cv")
h=h.replace('</script></body></html>',open('bignum.js').read()+open('coverdraw.js').read()+'\n</script></body></html>')
open('cover.html','w').write(h)
P
python3 shot_cover.py >/dev/null && ffmpeg -y -loglevel error -i cover_h.png -q:v 2 "/mnt/user-data/outputs/$2_封面_横4比3.jpg" && ffmpeg -y -loglevel error -i cover_v.png -q:v 2 "/mnt/user-data/outputs/$2_封面_竖3比4.jpg" && ffmpeg -y -loglevel error -i cover_h.png -i cover_v.png -filter_complex "[0]scale=-1:600[a];[1]scale=-1:600[b];[a][b]hstack" chkc.jpg && echo COVER_OK
