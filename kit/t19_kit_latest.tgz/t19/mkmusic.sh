#!/bin/bash
# usage: mkmusic.sh '<json>' outdir
python3 /home/claude/t19/synth20.py "$1" "$2/music_raw.wav" && ffmpeg -y -loglevel error -i "$2/music_raw.wav" -af "volume=10.5dB,alimiter=limit=0.89:attack=2:release=80:level=false" -ar 44100 "$2/music_end.wav" && ffmpeg -i "$2/music_end.wav" -af ebur128 -f null - 2>&1 | grep -E "^\s+I:" | tail -1
