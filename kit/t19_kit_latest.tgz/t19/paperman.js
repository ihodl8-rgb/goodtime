// ===== refined layered paper-cut figure =====
const PM={torso:150,neck:18,head:[36,42],ua:80,fa:74,th:100,sh:98};
const COL={skin:'#efe1cc',skinD:'#d9c8ae',hood:'#56709a',hoodD:'#435a80',pant:'#2b3242',pantD:'#222836',hair:'#20242c',shoe:'#ece7dc',shoeD:'#cfc8ba'};
const _pc2=document.createElement('canvas');_pc2.width=W;_pc2.height=H;const pg=_pc2.getContext('2d');
const dirV=(ang)=>[Math.sin(ang*Math.PI/180),Math.cos(ang*Math.PI/180)];// angle 0=down, 90=forward(right), 180=up
function seg(p,ang,len){const d=dirV(ang);return[p[0]+d[0]*len,p[1]+d[1]*len];}
function taper(g,a,b,ra,rb){const an=Math.atan2(b[1]-a[1],b[0]-a[0]);g.beginPath();g.arc(a[0],a[1],ra,an+Math.PI/2,an+Math.PI*1.5);g.arc(b[0],b[1],rb,an-Math.PI/2,an+Math.PI/2);g.closePath();}
function piece(g,pathFn,col,colD,lightAng=-0.6){g.save();g.shadowColor='rgba(0,0,0,0.42)';g.shadowBlur=7;g.shadowOffsetX=2.5;g.shadowOffsetY=3.5;pathFn(g);g.fillStyle=col;g.fill();g.restore();
  g.save();pathFn(g);g.clip();const gr=g.createLinearGradient(-200,-500,200,100);gr.addColorStop(0,'rgba(255,255,255,0.10)');gr.addColorStop(1,'rgba(0,0,0,0.14)');g.fillStyle=gr;g.fillRect(-600,-900,1200,1300);g.restore();
  g.save();pathFn(g);g.strokeStyle=colD;g.lineWidth=1.4;g.stroke();g.restore();}
function torsoPath(hip,sh,front,wS,wW,wH){return g=>{const an=Math.atan2(sh[1]-hip[1],sh[0]-hip[0]);const nx=-Math.sin(an),ny=Math.cos(an);const m=[(hip[0]+sh[0])/2,(hip[1]+sh[1])/2];
  g.beginPath();g.moveTo(hip[0]+nx*wH,hip[1]+ny*wH);g.quadraticCurveTo(m[0]+nx*wW,m[1]+ny*wW,sh[0]+nx*wS,sh[1]+ny*wS);g.quadraticCurveTo(sh[0]+(sh[0]-hip[0])*0.12,sh[1]+(sh[1]-hip[1])*0.12,sh[0]-nx*wS,sh[1]-ny*wS);
  g.quadraticCurveTo(m[0]-nx*wW,m[1]-ny*wW,hip[0]-nx*wH,hip[1]-ny*wH);g.quadraticCurveTo(hip[0]-(sh[0]-hip[0])*0.08,hip[1]-(sh[1]-hip[1])*0.08,hip[0]+nx*wH,hip[1]+ny*wH);g.closePath();};}
// P: {front, torso, head, A:[[ua,fa],[ua,fa]] (far, near), L:[[th,sh,foot],[...]], eye:0..1 open}
function paperMan(x,y,s,P,a=1,dim=0,t=0,sink=null,faceLight=0){if(a<=0.003)return;const g=pg;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,W,H);g.translate(x,y);g.scale(s,s);g.lineJoin='round';
  const F=P.front;const hip=[0,0];const sh=seg(hip,P.torso,PM.torso);const neck=seg(sh,P.torso,6);const hc=seg(neck,P.head,PM.neck+PM.head[1]*0.9);
  const sOff=F?[[-36,0],[36,0]]:[[-5,0],[5,0]];const hOff=F?[[-17,0],[17,0]]:[[-4,0],[4,0]];
  const arm=(i)=>{const s0=[sh[0]+sOff[i][0],sh[1]+sOff[i][1]+8];const el=seg(s0,P.A[i][0],PM.ua);const wr=seg(el,P.A[i][1],PM.fa);const hd=seg(wr,P.A[i][1]+(P.A[i][2]||0),16);return[s0,el,wr,hd];};
  const leg=(i)=>{const h0=[hip[0]+hOff[i][0],hip[1]];const kn=seg(h0,P.L[i][0],PM.th);const an=seg(kn,P.L[i][1],PM.sh);const toe=seg(an,P.L[i][2]!=null?P.L[i][2]:(F?(i?100:-100):90),30);return[h0,kn,an,toe];};
  const drawLeg=(i,far)=>{const[h0,kn,an,toe]=leg(i);const c=far?COL.pantD:COL.pant;piece(g,gg=>taper(gg,h0,kn,21,17),c,'#151920');piece(g,gg=>taper(gg,kn,an,17,13),c,'#151920');
    piece(g,gg=>{taper(gg,[an[0]-(toe[0]-an[0])*0.25,an[1]+2],toe,14,9);},far?COL.shoeD:COL.shoe,'#9d968a');};
  const drawArm=(i,far)=>{const[s0,el,wr,hd]=arm(i);piece(g,gg=>taper(gg,s0,el,17,14),far?COL.hoodD:COL.hood,'#2c3442');piece(g,gg=>taper(gg,el,wr,14,11),far?COL.hoodD:COL.hood,'#2c3442');
    piece(g,gg=>{gg.beginPath();gg.ellipse(hd[0],hd[1],12,15,Math.atan2(hd[1]-wr[1],hd[0]-wr[0])+Math.PI/2,0,6.283);},far?COL.skinD:COL.skin,'#a8987e');
    piece(g,gg=>taper(gg,seg(wr,P.A[i][1]+180,6),wr,12.5,12.5),'#e8e3d8','#b8b0a2');};// cuff
  // back to front
  drawArm(0,true);if(!F)drawLeg(0,true);
  // hood back
  piece(g,gg=>{gg.beginPath();const hb=seg(sh,P.torso+180,-4);gg.ellipse(hb[0]-(F?0:14),hb[1]-6,F?50:40,30,0,0,6.283);},COL.hoodD,'#2c3442');
  if(F){drawLeg(0,false);drawLeg(1,false);}else drawLeg(1,false);
  piece(g,torsoPath(hip,sh,F,F?44:34,F?36:30,F?34:30),COL.hood,'#2c3442');
  // pocket + zipper/drawstrings
  g.save();const mid=seg(hip,P.torso,PM.torso*0.35);g.strokeStyle='rgba(30,36,46,0.55)';g.lineWidth=1.6;g.beginPath();if(F){g.moveTo(mid[0]-26,mid[1]);g.quadraticCurveTo(mid[0],mid[1]+10,mid[0]+26,mid[1]);g.moveTo(sh[0]-6,sh[1]+14);g.lineTo(sh[0]-8,sh[1]+50);g.moveTo(sh[0]+6,sh[1]+14);g.lineTo(sh[0]+8,sh[1]+50);}
  else{g.moveTo(mid[0]+4,mid[1]-14);g.quadraticCurveTo(mid[0]+22,mid[1],mid[0]+6,mid[1]+18);}g.stroke();g.restore();
  // neck + head
  piece(g,gg=>taper(gg,sh,neck,11,11),COL.skinD,'#a8987e');
  const ha=(P.head-180)*Math.PI/180;
  piece(g,gg=>{gg.beginPath();gg.ellipse(hc[0],hc[1],PM.head[0],PM.head[1],-ha*0.6,0,6.283);},COL.skin,'#a8987e');
  // hair cap (paper)
  piece(g,gg=>{gg.save();gg.translate(hc[0],hc[1]);gg.rotate(-ha*0.6);gg.beginPath();if(F){gg.moveTo(-38,4);gg.bezierCurveTo(-44,-50,44,-56,38,2);gg.lineTo(30,-14);gg.lineTo(18,-6);gg.lineTo(6,-18);gg.lineTo(-8,-8);gg.lineTo(-22,-16);gg.lineTo(-30,-4);gg.closePath();}
    else{gg.moveTo(-36,14);gg.bezierCurveTo(-46,-46,30,-60,38,-14);gg.lineTo(22,-20);gg.lineTo(14,-10);gg.lineTo(2,-22);gg.lineTo(-8,-6);gg.lineTo(-20,-4);gg.lineTo(-22,20);gg.closePath();}gg.restore();},COL.hair,'#0e1014');
  // face: sleepy eye(s), tiny blush; phone light
  g.save();g.translate(hc[0],hc[1]);g.rotate(-ha*0.6);g.strokeStyle='#2a2e36';g.lineWidth=2.4;g.lineCap='round';const op=P.eye==null?0.4:P.eye;
  const eye=(ex,ey)=>{g.beginPath();g.moveTo(ex-7,ey);g.quadraticCurveTo(ex,ey+4+3*op,ex+7,ey);g.stroke();if(op>0.3){g.fillStyle='#2a2e36';g.beginPath();g.arc(ex,ey+2,2.6*op,0,6.283);g.fill();}};
  if(F){eye(-13,8);eye(13,8);}else{eye(18,6);}g.fillStyle='rgba(230,140,130,0.25)';g.beginPath();g.arc(F?-20:14,20,6,0,6.283);if(F)g.arc(20,20,6,0,6.283);g.fill();g.restore();
  if(!F)drawArm(1,false);else drawArm(1,false);
  // paper grain over everything
  g.setTransform(1,0,0,1,0,0);g.globalCompositeOperation='source-atop';g.globalAlpha=0.32;g.fillStyle=g.createPattern(_gr,'repeat');g.fillRect(0,0,W,H);g.globalAlpha=1;
  if(faceLight>0){const fx2=x+hc[0]*s,fy2=y+hc[1]*s;const fl=g.createRadialGradient(fx2+40*s,fy2+10*s,4,fx2+40*s,fy2+10*s,160*s);fl.addColorStop(0,`rgba(120,170,255,${0.45*faceLight})`);fl.addColorStop(1,'rgba(120,170,255,0)');g.fillStyle=fl;g.fillRect(0,0,W,H);}
  if(dim>0){g.globalCompositeOperation='destination-out';SHARDS.forEach(([u,v,w,h,r2])=>{if(h>=dim)return;const px=x+(u-0.5)*120*s,py=y+(-v*430+20)*s;g.save();g.translate(px,py);g.rotate(r2*6);g.beginPath();g.moveTo(-22*s,-12*s);g.lineTo(20*s,-20*s);g.lineTo(24*s,14*s);g.lineTo(-14*s,22*s);g.closePath();g.fill();g.restore();});}
  g.globalCompositeOperation='source-over';
  ctx.save();ctx.globalAlpha*=a;ctx.shadowColor='rgba(0,0,0,0.75)';ctx.shadowBlur=30;ctx.shadowOffsetX=12;ctx.shadowOffsetY=16;ctx.drawImage(_pc2,0,0);ctx.restore();
  if(dim>0&&sink){SHARDS.forEach(([u,v,w,h,r2],i)=>{if(h>=dim)return;const k=clamp((dim-h)*2.2);if(k>=1)return;const sx=x+(u-0.5)*120*s,sy=y+(-v*430+20)*s;const px=lerp(sx,sink[0],eio(k))+Math.sin(k*9+i)*30*(1-k),py=lerp(sy,sink[1],eio(k))+Math.cos(k*7+i)*20*(1-k);
    ctx.save();ctx.translate(px,py);ctx.rotate(k*8+r2*6);ctx.scale(1,Math.cos(k*10+i));ctx.globalAlpha=a*(1-k*0.7);ctx.fillStyle=i%3?COL.hood:'#efe9dc';ctx.beginPath();ctx.moveTo(-11,-7);ctx.lineTo(10,-10);ctx.lineTo(12,8);ctx.lineTo(-8,11);ctx.closePath();ctx.fill();ctx.restore();});}}
// poses (absolute angles; 0 down, 90 forward/right, 180 up)
function P_stand(t,k){const j=Math.sin(t*5)*4*k;return{front:true,torso:180,head:180+Math.sin(t*1.2)*3,A:[[-38-j,-52-j],[38+j,52+j]],L:[[-4,-2],[4,2]],eye:0.7};}
function P_sit(t){return{front:false,torso:168,head:142+Math.sin(t*1.1)*2,A:[[28,128,10],[22,122,10]],L:[[92,2,90],[88,0,90]],eye:0.45};}
function P_pull(t){const j=Math.sin(t*7)*5;return{front:false,torso:158,head:158,A:[[146+j,150+j],[140+j,146+j]],L:[[92,4,90],[86,0,90]],eye:0.9};}
function P_curl(t){return{front:false,torso:170,head:136+Math.sin(t*1.0)*2,A:[[40,112,8],[34,104,8]],L:[[132,18,90],[126,14,90]],eye:0.35};}
function pmHand(x,y,s,P,i){const sh=seg([0,0],P.torso,PM.torso);const s0=[sh[0]+(P.front?(i?36:-36):(i?5:-5)),sh[1]+8];const el=seg(s0,P.A[i][0],PM.ua);const wr=seg(el,P.A[i][1],PM.fa);const hd=seg(wr,P.A[i][1],16);return[x+hd[0]*s,y+hd[1]*s];}
