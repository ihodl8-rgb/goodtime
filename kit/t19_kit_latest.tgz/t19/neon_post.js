
const _pm0=paperMan;
paperMan=function(x,y,s,P,a=1,dim=0,t=0,sink=null,faceLight=0){if(a<=0.003)return;
  const k0=skPts(P);const feetY=Math.max(...k0.legs.map(l=>l[3][1]))*s+y+4;if(Math.abs(feetY-1184)>8&&Math.abs(feetY-1154)>8)return _pm0(x,y,s,P,a,dim,t,sink,faceLight);
  // colored light pool on the floor
  ctx.save();ctx.globalCompositeOperation='lighter';ctx.translate(x,feetY);ctx.scale(1,0.2);halo(0,0,220*s,AC,0.30*a*(1-dim*0.7));halo(0,0,90*s,[255,255,255],0.18*a*(1-dim*0.7));ctx.restore();
  return _pm0(x,y,s,P,a,dim,t,sink,faceLight);};
