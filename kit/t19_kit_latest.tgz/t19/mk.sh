#!/bin/bash
# usage: mk.sh dir   (dir contains cfg.part scenes.part)
set -e; D=$1; cd $D
for f in bx.js paperman.js stick2.js face_n.js polish.js neon_post.js render_ss.py timeline.json head.part cap.part tail.part shot_cover.py helpers.part build.py lib.part bignum.js coverdraw.js; do [ -f $f ] || cp /home/claude/t19/$f .; done
cat head.part helpers.part cfg.part lib.part bignum.js scenes.part cap.part tail.part > fk.js && python3 build.py >/dev/null
node -e "const s=require('fs').readFileSync('index.html','utf8');const m=s.match(/<script>([\s\S]*)<\/script>/);require('fs').writeFileSync('/tmp/claude-0/-home-claude/1fcb31bc-e9a2-5123-9037-be861d2f34dc/scratchpad/all.js',m[1])" && node --check /tmp/claude-0/-home-claude/1fcb31bc-e9a2-5123-9037-be861d2f34dc/scratchpad/all.js && echo BUILD_OK
