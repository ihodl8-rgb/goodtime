#!/bin/bash
# regenerate covers for listed "dir name" pairs; build sheet
S=/tmp/claude-0/-home-claude/1fcb31bc-e9a2-5123-9037-be861d2f34dc/scratchpad
while read d n; do (cd /home/claude/$d && cp /home/claude/t19/coverdraw.js . && bash /home/claude/t19/cover.sh /home/claude/$d $n >/dev/null && echo "$n ok") < /dev/null; done
