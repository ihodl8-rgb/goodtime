#!/bin/bash
while ! grep -q e80 /home/claude/t19/done.txt; do sleep 10; done
for e in "75 全人类跳一下" "76 拿破仑其实不矮" "77 对折42次" "78 章鱼来相亲" "79 安慰剂按钮" "80 体内大选"; do set -- $e; /home/claude/t19/patchend.sh /home/claude/e$1 $1_$2 > /home/claude/e$1/patch.log 2>&1; echo "$1 $(tail -1 /home/claude/e$1/patch.log)"; done
echo ALL_PATCHED
