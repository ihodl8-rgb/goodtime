#!/bin/bash
# re-render end card (frames >= 495) and splice with existing video's first 495 frames
cd $1; /home/claude/t19/mk.sh $1 >/dev/null; rm -rf frames; mkdir frames
ffmpeg -loglevel error -i "/mnt/user-data/outputs/$2_视频.mp4" -vf "select=lt(n\,495)" -vsync 0 -start_number 0 frames/f%05d.png
C=27; for i in 0 1 2 3 4; do s=$((495+i*C)); e=$((s+C)); [ $e -gt 630 ] && e=630; python3 render_ss.py full $s $e frames > p$i.log 2>&1 & done; wait
n=$(ls frames | wc -l); echo frames $n
ffmpeg -y -loglevel error -framerate 30 -i frames/f%05d.png -i music_end.wav -vf scale=1080:1440:flags=lanczos -c:v libx264 -crf 14 -preset slow -tune animation -pix_fmt yuv420p -c:a aac -b:a 256k -shortest -movflags +faststart preview.mp4 && cp preview.mp4 "/mnt/user-data/outputs/$2_视频.mp4" && rm -rf frames && echo PATCH_DONE
