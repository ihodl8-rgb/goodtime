// ===== stick figure v2: tapered brush strokes, eyes, animated poses (overrides) =====
const SK={torso:132,neck:12,head:34,ua:74,fa:70,th:96,sh:92};
const lerpA=(a,b,k)=>a+(b-a)*k;
function lerpP(P,Q,k){const L=(x,y)=>Array.isArray(x)?x.map((v,i)=>L(v,y[i])):(typeof x==='number'?lerpA(x,y,k):(k<0.5?x:y));const o={};for(const key in P)o[key]=L(P[key],Q[key]);return o;}
function skPts(P){const d=a=>[Math.sin(a*Math.PI/180),Math.cos(a*Math.PI/180)];const S=(p,a,l)=>{const v=d(a);return[p[0]+v[0]*l,p[1]+v[1]*l];};
  const hip=[P.dx||0,P.dy||0];const sh=S(hip,P.torso,SK.torso);const nk=S(sh,P.torso,SK.neck);const hc=S(nk,P.head,SK.head+4);
  const arm=i=>{const s0=S(sh,P.torso+180,8);const el=S(s0,P.A[i][0],SK.ua);const wr=S(el,P.A[i][1],SK.fa);return[s0,el,wr];};
  const leg=i=>{const kn=S(hip,P.L[i][0],SK.th);const an=S(kn,P.L[i][1],SK.sh);const toe=S(an,P.L[i][2]!=null?P.L[i][2]:90,20);return[hip,kn,an,toe];};
  return{hip,sh,nk,hc,arms:[arm(0),arm(1)],legs:[leg(0),leg(1)]};}
function brushSeg(a,b,w1,w2){const an=Math.atan2(b[1]-a[1],b[0]-a[0]);ctx.beginPath();ctx.arc(a[0],a[1],w1/2,an+Math.PI/2,an+Math.PI*1.5);ctx.arc(b[0],b[1],w2/2,an-Math.PI/2,an+Math.PI/2);ctx.closePath();ctx.fill();}
function drawStick(x,y,s,P,al,t,glow=1){const k=skPts(P);const tr=p=>[x+p[0]*s,y+p[1]*s];
  const body=(wMul,fill)=>{ctx.fillStyle=fill;const B=(a,b,w1,w2)=>brushSeg(tr(a),tr(b),w1*s*wMul,w2*s*wMul);
    B(k.hip,k.sh,15,13);B(k.sh,k.nk,10,9);
    k.legs.forEach(([h,kn,an,toe])=>{B(h,kn,13,11);B(kn,an,11,9);B(an,toe,9,7);});
    k.arms.forEach(([s0,el,wr])=>{B(s0,el,11,9);B(el,wr,9,7);});
    const c=tr(k.hc);ctx.beginPath();ctx.arc(c[0],c[1],(SK.head+5*wMul)*s,0,6.283);ctx.fill();};
  ctx.save();ctx.globalAlpha*=al;
  // glow layers
  ctx.save();ctx.globalCompositeOperation='lighter';ctx.shadowColor=rgba(AC,0.9);ctx.shadowBlur=36*glow;body(2.2,rgba(AC,0.22*glow));ctx.restore();
  ctx.shadowColor=rgba(AC2,0.9);ctx.shadowBlur=12;body(1,'rgba(255,244,240,1)');ctx.shadowBlur=0;
  // head: dark face disc + eyes looking along facing
  const c=tr(k.hc);const r=SK.head*s;ctx.fillStyle='#070a10';ctx.beginPath();ctx.arc(c[0],c[1],r-6*s,0,6.283);ctx.fill();
  const ha=(P.head-180)*Math.PI/180;const fx=P.front?0:1;const ex=c[0]+(P.front?0:r*0.38)*Math.cos(ha)-0,ey=c[1]+(P.front?0:r*0.38)*Math.sin(ha)+r*0.05;
  const blink=((t*0.37)%1)>0.94?0.15:1;const op=(P.eye==null?0.6:P.eye)*blink;
  ctx.fillStyle='rgba(255,244,240,1)';const eye=(xx,yy)=>{ctx.beginPath();ctx.ellipse(xx,yy,4.2*s,Math.max(0.8,5.5*op)*s,ha,0,6.283);ctx.fill();};
  if(P.front){eye(c[0]-r*0.3,c[1]+r*0.02);eye(c[0]+r*0.3,c[1]+r*0.02);}else{eye(ex+r*0.12,ey);eye(ex-r*0.32,ey+r*0.02);}
  ctx.restore();return k;}
function paperMan(x,y,s,P,a=1,dim=0,t=0,sink=null,faceLight=0){if(a<=0.003)return;
  // contact shadow
  const k0=skPts(P);const feetY=Math.max(...k0.legs.map(l=>l[3][1]))*s+y;ctx.save();ctx.globalCompositeOperation='lighter';ctx.translate(x,feetY+6);ctx.scale(1,0.18);halo(0,0,150*s,AC,0.25*a);ctx.restore();
  // motion trail from the pose a moment ago
  if(P.prev){for(let g=3;g>=1;g--){drawStick(x,y,s,lerpP(P,P.prev,g/3),a*0.10*(4-g),t,0.5);}}
  if(dim>0){ctx.save();ctx.globalAlpha=1-dim*0.65;}
  const k=drawStick(x,y,s,P,a,t,1-dim*0.6);if(dim>0)ctx.restore();
  if(faceLight>0){const c=[x+k.hc[0]*s,y+k.hc[1]*s];ctx.save();ctx.globalCompositeOperation='lighter';halo(c[0]+36*s,c[1]+4*s,110*s,[255,135,115],0.4*faceLight);ctx.restore();}
  if(dim>0&&sink){SHARDS.forEach(([u,v,w,h,r2],i)=>{if(h>=dim)return;const kk=clamp((dim-h)*2.2);if(kk>=1)return;const sx=x+(u-0.5)*110*s,sy=y+(-v*330+60)*s;const px=lerp(sx,sink[0],eio(kk))+Math.sin(kk*9+i)*30*(1-kk),py=lerp(sy,sink[1],eio(kk))+Math.cos(kk*7+i)*20*(1-kk);
    ctx.save();ctx.translate(px,py);ctx.rotate(kk*6+r2*6);ctx.globalCompositeOperation='lighter';ctx.strokeStyle='rgba(255,240,225,0.95)';ctx.shadowColor='rgba(245,95,80,0.9)';ctx.shadowBlur=10;ctx.lineWidth=5;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(-8,0);ctx.lineTo(8,0);ctx.stroke();ctx.restore();});}}
function pmHand(x,y,s,P,i){const k=skPts(P);const w=k.arms[i][2];return[x+w[0]*s,y+w[1]*s];}
// ---- animated poses (t = global time) ----
const POSE={
  stand:{front:true,dx:0,dy:-190,torso:180,head:180,A:[[-30,-40],[30,40]],L:[[-5,-3,-100],[5,3,100]],eye:0.8},
  yankL:{front:true,dx:-14,dy:-188,torso:192,head:200,A:[[-78,-96],[22,14]],L:[[-12,-4,-100],[3,10,100]],eye:0.3},
  yankR:{front:true,dx:14,dy:-188,torso:168,head:160,A:[[-22,-14],[78,96]],L:[[-3,-10,-100],[12,4,100]],eye:0.3},
  sit:{front:false,dx:0,dy:0,torso:164,head:132,A:[[30,122],[22,118]],L:[[92,4,90],[86,0,90]],eye:0.45},
  standSide:{front:false,dx:-10,dy:-85,torso:178,head:175,A:[[8,10],[-6,-4]],L:[[6,2,90],[-4,-2,90]],eye:0.7},
  crouch:{front:false,dx:-6,dy:4,torso:150,head:150,A:[[60,90],[50,80]],L:[[96,6,90],[90,0,90]],eye:0.9},
  reach:{front:false,dx:6,dy:-6,torso:162,head:160,A:[[150,156],[142,150]],L:[[90,4,90],[84,0,90]],eye:1},
  tug:{front:false,dx:-8,dy:0,torso:186,head:172,A:[[132,128],[126,122]],L:[[98,10,90],[94,6,90]],eye:1},
  slump:{front:false,dx:4,dy:6,torso:138,head:110,A:[[10,60],[4,54]],L:[[92,4,90],[86,0,90]],eye:0.1},
  curl:{front:false,dx:0,dy:0,torso:168,head:134,A:[[52,112],[44,104]],L:[[136,16,90],[128,12,90]],eye:0.35}};
function poseAt(fn,t){const P=fn(t);P.prev=fn(t-0.05);P.prev.prev=null;return P;}
function aStand(t){const lt=t-0;const ph=(lt*2.6)%2;const k1=ss(0.0,0.18,ph%1)*(1-ss(0.45,0.95,ph%1));return lerpP(POSE.stand,ph<1?POSE.yankL:POSE.yankR,k1*0.9);}
function aSit(t){const lt=t-B[1];if(lt<0.45){const k=eio(clamp(lt/0.45));return lerpP(POSE.standSide,POSE.crouch,k);}const k=eio(clamp((lt-0.45)/0.4));const P=lerpP(POSE.crouch,POSE.sit,k);P.head+=Math.sin(t*1.3)*2;return P;}
function aPull(t){const lt=t-B[2];if(lt<0.25)return lerpP(POSE.sit,POSE.crouch,eio(lt/0.25));if(lt<0.5)return lerpP(POSE.crouch,POSE.reach,eio((lt-0.25)/0.25));const c=((lt-0.5)*2.4)%1;const k=c<0.35?eio(c/0.35):1-eio((c-0.35)/0.65);return lerpP(POSE.reach,POSE.tug,k);}
function aSlump(t){const lt=t-B[3];return lerpP(POSE.sit,POSE.slump,eio(clamp(lt/1.6)));}
function aCurl(t){const P=lerpP(POSE.curl,POSE.curl,0);P.torso+=Math.sin(t*1.6)*2;P.head+=Math.sin(t*1.6-0.6)*3;return P;}
function P_stand(t){return poseAt(aStand,t);}function P_sit(t){return t<B[2]?poseAt(aSit,t):poseAt(aSlump,t);}function P_pull(t){return poseAt(aPull,t);}function P_curl(t){return poseAt(aCurl,t);}
