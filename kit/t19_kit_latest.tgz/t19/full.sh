#!/bin/bash
# usage: full.sh dir name  -> renders, repairs, encodes, copies to outputs/NN_name_视频.mp4
cd $1; NF=$(python3 -c "import re;s=open('bx.js').read();print(round(float(re.search(r'DUR=([0-9.]+)',s).group(1))*30))")
C=$(( (NF+4)/5 ))
if [ -d frames ] && [ $(ls frames | wc -l) -gt 0 ]; then echo RESUME; else mkdir -p frames; for i in 0 1 2 3 4; do s=$((i*C)); e=$((s+C)); [ $e -gt $NF ] && e=$NF; python3 render_ss.py full $s $e frames > r$i.log 2>&1 & done; fi
wait
python3 - <<P
import os
from PIL import Image
NF=$NF;miss=[]
for i in range(NF):
  f='frames/f%05d.png'%i
  try: Image.open(f).verify()
  except Exception: miss.append(i)
open('miss.txt','w').write(' '.join(map(str,miss)));print('missing',len(miss))
P
for i in $(cat miss.txt); do python3 render_ss.py full $i $((i+1)) frames >/dev/null 2>&1; done
ffmpeg -y -loglevel error -framerate 30 -i frames/f%05d.png -i music_end.wav -vf scale=1080:1440:flags=lanczos -c:v libx264 -crf 14 -preset slow -tune animation -pix_fmt yuv420p -c:a aac -b:a 256k -shortest -movflags +faststart preview.mp4
cp preview.mp4 "/mnt/user-data/outputs/$2_视频.mp4"; ffprobe -v error -show_entries format=duration -of csv=p=0 preview.mp4; rm -rf frames; echo FULL_DONE
