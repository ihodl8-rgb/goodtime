// ===== polish layer: richer stage, glass bubbles, gradient title text, grain =====
const BOKEH=(()=>{const R=mulberry32(99);return Array.from({length:26},()=>[R()*W,R()*H*0.85,30+R()*110,R(),R()*6.28]);})();
const _grain=(()=>{const c=document.createElement('canvas');c.width=256;c.height=256;const g=c.getContext('2d');const R=mulberry32(5);const im=g.createImageData(256,256);for(let i=0;i<im.data.length;i+=4){const v=R()*255;im.data[i]=im.data[i+1]=im.data[i+2]=v;im.data[i+3]=255;}g.putImageData(im,0,0);return c;})();
stage=function(t,spot=1,cx=CX){
  const bg=ctx.createLinearGradient(0,0,0,H);bg.addColorStop(0,'#120a10');bg.addColorStop(0.55,'#1d1018');bg.addColorStop(1,'#06040a');ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
  ctx.save();ctx.globalCompositeOperation='lighter';
  halo(W*0.12,H*0.18,620,[120,40,60],0.35);halo(W*0.95,H*0.62,560,[120,60,150],0.16);halo(cx,H*0.42,700,[150,60,70],0.18*spot);
  BOKEH.forEach(([x,y,r,h,ph])=>{const a=(0.035+0.03*Math.sin(t*0.7+ph))*(0.6+0.4*h);const yy=y-Math.sin(t*0.2+ph)*20;const g=ctx.createRadialGradient(x,yy,r*0.6,x,yy,r);g.addColorStop(0,rgba(h>0.75?[200,150,255]:AC2,a));g.addColorStop(0.85,rgba(AC2,a*0.8));g.addColorStop(1,rgba(AC2,0));ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,yy,r,0,6.283);ctx.fill();});
  // volumetric light: three soft cones + rays
  [[1,0.10],[0.72,0.10],[0.45,0.12]].forEach(([wk,al])=>{const g=ctx.createLinearGradient(0,0,0,1180);g.addColorStop(0,rgba([255,235,228],al*1.4*spot));g.addColorStop(1,rgba([245,190,180],al*0.35*spot));ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(cx-60*wk,-20);ctx.lineTo(cx+60*wk,-20);ctx.lineTo(cx+420*wk,1180);ctx.lineTo(cx-420*wk,1180);ctx.closePath();ctx.fill();});
  for(let i=0;i<7;i++){const u=(i/6-0.5)*0.9+Math.sin(t*0.4+i)*0.03;ctx.strokeStyle=rgba([255,240,235],0.035*spot);ctx.lineWidth=18+i%3*14;ctx.beginPath();ctx.moveTo(cx+u*80,-20);ctx.lineTo(cx+u*820,1180);ctx.stroke();}
  // dust
  DUST.forEach(([x,y,r,h,ph])=>{const yy=(((y-t*(8+12*h))%H)+H)%H;const inCone=Math.abs(x-cx)<70+yy*0.3;dot(x+Math.sin(t*0.5+ph)*12,yy,r*(inCone?1.2:0.8),[255,240,236],(inCone?0.7:0.12)*spot*(0.5+0.5*Math.sin(t*1.3+ph)));});
  ctx.restore();
  // glossy floor
  const fy=1180;const fl=ctx.createLinearGradient(0,fy-10,0,H);fl.addColorStop(0,'rgba(60,25,30,0.55)');fl.addColorStop(0.15,'rgba(25,10,14,0.6)');fl.addColorStop(1,'rgba(2,5,8,0.9)');ctx.fillStyle=fl;ctx.fillRect(0,fy-4,W,H-fy+4);
  ctx.save();ctx.globalCompositeOperation='lighter';const hl=ctx.createLinearGradient(0,0,W,0);hl.addColorStop(0,'rgba(245,150,130,0)');hl.addColorStop(0.5,`rgba(255,190,175,${0.35*spot})`);hl.addColorStop(1,'rgba(245,150,130,0)');ctx.fillStyle=hl;ctx.fillRect(0,fy-3,W,2);
  ctx.translate(cx,fy+8);ctx.scale(1,0.16);halo(0,0,430,[255,190,175],0.42*spot);halo(0,0,180,[255,255,255],0.22*spot);ctx.restore();
  const v=ctx.createRadialGradient(CX,H*0.45,H*0.25,CX,H*0.45,H*0.82);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(0,0,0,0.62)');ctx.fillStyle=v;ctx.fillRect(0,0,W,H);};
// glass bubbles
bubble=function(s,x,y,a,side,pop=1){if(a<=0.003)return;const fs=42;const w=TW(s,fs,700,SRF,1)+60,h=78;ctx.save();ctx.translate(x,y);ctx.scale(pop,pop);ctx.globalAlpha*=a;
  ctx.shadowColor='rgba(0,0,0,0.55)';ctx.shadowBlur=24;ctx.shadowOffsetY=10;const g=ctx.createLinearGradient(0,-h/2,0,h/2);
  if(side<0){g.addColorStop(0,'rgba(110,60,64,0.62)');g.addColorStop(1,'rgba(40,18,22,0.78)');}else{g.addColorStop(0,'rgba(240,110,95,0.78)');g.addColorStop(1,'rgba(150,45,45,0.85)');}
  ctx.fillStyle=g;ctx.beginPath();ctx.roundRect(-w/2,-h/2,w,h,h/2);ctx.fill();ctx.shadowColor='transparent';
  ctx.beginPath();ctx.moveTo(side*(w/2-34),h/2-4);ctx.lineTo(side*(w/2-4),h/2+16);ctx.lineTo(side*(w/2-56),h/2-4);ctx.fill();
  const st=ctx.createLinearGradient(0,-h/2,0,h/2);st.addColorStop(0,'rgba(255,255,255,0.55)');st.addColorStop(0.5,'rgba(255,255,255,0.08)');st.addColorStop(1,'rgba(255,255,255,0.18)');ctx.strokeStyle=st;ctx.lineWidth=2;ctx.beginPath();ctx.roundRect(-w/2,-h/2,w,h,h/2);ctx.stroke();
  ctx.fillStyle='rgba(255,255,255,0.10)';ctx.beginPath();ctx.roundRect(-w/2+10,-h/2+5,w-20,h*0.36,h*0.2);ctx.fill();
  ctx.font=`700 ${fs}px ${SRF}`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.shadowColor='rgba(0,0,0,0.5)';ctx.shadowBlur=6;ctx.fillStyle='rgba(248,253,255,1)';ctx.fillText(s,0,2);ctx.restore();};
// premium title text: gradient, stroke, double glow, sweep
function lumText(s,x,y,size,t,sp=10){ctx.save();ctx.font=`900 ${size}px ${SRF}`;ctx.textAlign='center';ctx.textBaseline='middle';try{ctx.letterSpacing=sp+'px';}catch(e){}
  ctx.globalCompositeOperation='lighter';ctx.shadowColor='rgba(245,95,80,0.9)';ctx.shadowBlur=70;ctx.fillStyle='rgba(180,60,60,0.55)';ctx.fillText(s,x,y);ctx.restore();
  ctx.save();ctx.font=`900 ${size}px ${SRF}`;ctx.textAlign='center';ctx.textBaseline='middle';try{ctx.letterSpacing=sp+'px';}catch(e){}
  ctx.lineJoin='round';ctx.strokeStyle='rgba(30,8,10,0.9)';ctx.lineWidth=size*0.07;ctx.strokeText(s,x,y);
  const g=ctx.createLinearGradient(0,y-size/2,0,y+size/2);g.addColorStop(0,'#ffffff');g.addColorStop(0.45,'#fff0ec');g.addColorStop(0.62,'#ffc2b5');g.addColorStop(1,'#f07a68');ctx.fillStyle=g;ctx.shadowColor='rgba(255,160,140,0.8)';ctx.shadowBlur=18;ctx.fillText(s,x,y);
  ctx.restore();{const oc=document.createElement('canvas');const sc=(typeof SS!=='undefined'?SS:1);const ow=Math.ceil(W*sc),oh=Math.ceil(size*2.2*sc);oc.width=ow;oc.height=oh;const o=oc.getContext('2d');o.setTransform(sc,0,0,sc,0,0);o.font=`900 ${size}px ${SRF}`;o.textAlign='center';o.textBaseline='middle';try{o.letterSpacing=sp+'px';}catch(e){}const m=ctx.getTransform();const cx0=W/2;o.fillStyle='#fff';o.fillText(s,cx0,size*1.1);o.globalCompositeOperation='source-in';const sx=((t*0.35)%1.6-0.3)*W;const sw=o.createLinearGradient(sx-120,0,sx+120,0);sw.addColorStop(0,'rgba(255,255,255,0)');sw.addColorStop(0.5,'rgba(255,255,255,0.7)');sw.addColorStop(1,'rgba(255,255,255,0)');o.fillStyle=sw;o.fillRect(0,0,W,size*2.2);ctx.save();ctx.drawImage(oc,x-cx0,y-size*1.1,W,size*2.2);ctx.restore();}ctx.save();ctx.restore();}
