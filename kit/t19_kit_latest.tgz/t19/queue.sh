#!/bin/bash
# usage: queue.sh dir name — serialized renders via flock
flock /home/claude/t19/render.lock bash -c "while pgrep -f 't20/full.sh /home/claude/e75' >/dev/null; do sleep 10; done; /home/claude/t19/full.sh $1 $2 > $1/full.log 2>&1"
