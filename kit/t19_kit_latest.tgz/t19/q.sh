#!/bin/bash
# sequential queue: processes /home/claude/t19/q.txt lines "dir name"; waits for new lines; stops at line END
i=1
while true; do
  l=$(sed -n "${i}p" /home/claude/t19/q.txt 2>/dev/null)
  if [ -z "$l" ]; then sleep 5; continue; fi
  [ "$l" = "END" ] && break
  set -- $l
  until ! pgrep -f "[f]ull.sh" >/dev/null; do sleep 5; done
  bash /home/claude/t19/full.sh $1 $2 > $1/full.log 2>&1 < /dev/null
  (cd $1 && cp /home/claude/t19/coverdraw.js . && bash /home/claude/t19/mk.sh . >/dev/null && bash /home/claude/t19/cover.sh $1 $2 >/dev/null)
  echo "DONE $2"
  i=$((i+1))
done
