// ===== 38 报复性熬夜 — concept short (12s loop), black stage, one accent = screen blue =====
const CX=W/2,DUR=19.467,HIT=15.0556;const SRF='"Noto Serif CJK SC", serif';
const IV=[236,240,246],DM=[140,150,166],AC=[255,120,100],AC2=[255,214,204];
function buildScenes(){}
const DUST=(()=>{const R=mulberry32(11);return Array.from({length:140},()=>[R()*W,R()*H,R()*1.6+0.4,R(),R()*6.28]);})();
function stage(t,spot=1,cx=CX){ctx.fillStyle='#040507';ctx.fillRect(0,0,W,H);
  ctx.save();ctx.globalCompositeOperation='lighter';const g=ctx.createLinearGradient(0,0,0,1150);g.addColorStop(0,`rgba(255,196,184,${0.20*spot})`);g.addColorStop(1,'rgba(255,196,184,0)');ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(cx-90,0);ctx.lineTo(cx+90,0);ctx.lineTo(cx+430,1150);ctx.lineTo(cx-430,1150);ctx.closePath();ctx.fill();
  const fl=ctx.createRadialGradient(cx,1060,10,cx,1060,460);fl.addColorStop(0,`rgba(255,185,170,${0.22*spot})`);fl.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=fl;ctx.save();ctx.translate(cx,1060);ctx.scale(1,0.22);ctx.translate(-cx,-1060);ctx.fillRect(cx-480,560,960,1000);ctx.restore();
  DUST.forEach(([x,y,r,h,ph])=>{const yy=(y-t*(8+12*h))%H;const yy2=yy<0?yy+H:yy;const inCone=Math.abs(x-cx)<90+yy2*0.3;dot(x+Math.sin(t*0.5+ph)*12,yy2,r,[255,240,236],(inCone?0.55:0.12)*spot*(0.5+0.5*Math.sin(t*1.3+ph)));});ctx.restore();
  const v=ctx.createRadialGradient(CX,H*0.45,H*0.3,CX,H*0.45,H*0.85);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(0,0,0,0.7)');ctx.fillStyle=v;ctx.fillRect(0,0,W,H);}
// ---- particle figure: points sampled on capsules; pose = joint table ----
const FIG=(()=>{const R=mulberry32(5);return Array.from({length:520},()=>[R(),R(),R(),R()]);})();
function capsPt(a,b,r,u,v){const x=lerp(a[0],b[0],u),y=lerp(a[1],b[1],u);const an=((u*97.31+v*13.7)%1)*6.283,rr=r*Math.sqrt(v);return[x+Math.cos(an)*rr,y+Math.sin(an)*rr*1.0];}
function pose(name,k=0){// returns segments [[a,b,r,weight]] in local coords (feet at 0,0), height ~420
  if(name==='stand'){const sw=k;return[[[0,-372],[0,-372],40,3],[[0,-312],[0,-180],32,4],[[0,-180],[0,-150],28,1],[[-18,-150],[-24,0],14,2],[[18,-150],[24,0],14,2],[[-34,-300],[-60-30*sw,-200],11,1.3],[[-60-30*sw,-200],[-70-70*sw,-130-30*sw],10,1.1],[[34,-300],[60+30*sw,-200],11,1.3],[[60+30*sw,-200],[70+70*sw,-130-30*sw],10,1.1]];}
  if(name==='sit'){return[[[0,-300],[0,-300],40,3],[[0,-246],[6,-120],32,4],[[6,-120],[90,-110],15,2],[[90,-110],[100,0],14,2],[[0,-120],[80,-100],15,1.5],[[80,-100],[96,0],14,1.5],[[-30,-230],[30,-160],11,1.2],[[30,-160],[70,-190],10,1],[[34,-232],[60,-170],11,1.2],[[60,-170],[78,-196],10,1]];}
  if(name==='pull'){return[[[-10,-300],[-10,-300],40,3],[[-8,-246],[0,-120],32,4],[[0,-120],[80,-110],15,2],[[80,-110],[96,0],14,2],[[0,-120],[70,-96],15,1.5],[[70,-96],[84,0],14,1.5],[[20,-236],[90,-300],11,1.3],[[90,-300],[150,-370],10,1.1],[[-30,-236],[30,-300],11,1.3],[[30,-300],[110,-360],10,1.1]];}
  if(name==='curl'){return[[[30,-170],[30,-170],38,3],[[0,-130],[-40,-60],32,4],[[-40,-60],[40,-60],16,2],[[40,-60],[60,0],14,2],[[-40,-60],[30,-40],16,1.5],[[10,-120],[60,-110],10,1],[[16,-140],[70,-120],10,1]];}}
function figure(x,y,s,segs,a=1,dim=0,t=0,col=IV,sink=null){if(a<=0.003)return;const tot=segs.reduce((p,q)=>p+q[3],0);ctx.save();ctx.globalCompositeOperation='lighter';
  FIG.forEach(([u,v,w,h],i)=>{let acc=0,sg=segs[0];const pick=w*tot;for(const q of segs){acc+=q[3];if(pick<=acc){sg=q;break;}}
    let[px,py]=capsPt(sg[0],sg[1],sg[2],u,v);px=x+px*s;py=y+py*s;px+=Math.sin(t*2+i)*1.2;py+=Math.cos(t*1.7+i)*1.2;
    let al=a*(0.55+0.45*Math.sin(t*3+i*0.7));const gone=dim>h;if(gone&&sink){const k=clamp((dim-h)*3);px=lerp(px,sink[0],eio(k));py=lerp(py,sink[1],eio(k));al*=1-k*0.6;}else if(dim>0)al*=1-dim*0.55;
    if(al>0.01){dot(px,py,2.4*s+0.6,col,al);}});
  ctx.restore();ctx.save();ctx.globalCompositeOperation='lighter';halo(x,y-200*s,240*s,[255,135,115],0.10*a*(1-dim*0.7));ctx.restore();}
// ---- clock ----
function clock(x,y,r,hh,mm,a=1,ghost=0,digital=''){if(a<=0.003)return;ctx.save();ctx.globalAlpha*=a;ctx.strokeStyle=rgba(IV,0.7);ctx.lineWidth=3;ctx.beginPath();ctx.arc(x,y,r,0,6.283);ctx.stroke();
  for(let i=0;i<12;i++){const an=i/12*6.283;ctx.lineWidth=i%3?2:4;ctx.beginPath();ctx.moveTo(x+Math.cos(an)*r*0.86,y+Math.sin(an)*r*0.86);ctx.lineTo(x+Math.cos(an)*r*0.96,y+Math.sin(an)*r*0.96);ctx.stroke();}
  const hand=(ang,len,w,al)=>{ctx.strokeStyle=rgba(AC2,al);ctx.lineWidth=w;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+Math.cos(ang)*len,y+Math.sin(ang)*len);ctx.stroke();};
  const ma=(mm/60)*6.283-1.5708,ha=((hh%12)+mm/60)/12*6.283-1.5708;
  for(let g=6;g>=1;g--){if(ghost<=0)break;hand(ma+g*0.12*ghost,r*0.8,4,0.12*(1-g/7));}
  hand(ha,r*0.5,7,0.95);hand(ma,r*0.8,4,0.95);ctx.fillStyle=rgba(AC2,1);ctx.beginPath();ctx.arc(x,y,7,0,6.283);ctx.fill();ctx.restore();
  if(digital)T(digital,x,y+r+48,40,AC,a,700,LAT,'center',4);}
// ---- captions: typed, last keyword in accent ----
function caption(head,key,t0,t,a=1,y=230){if(a<=0.003)return;const full=head+key,n=full.length;const shown=Math.floor(clamp((t-t0)/0.5)*n+0.001);const size=52;
  const w=TW(full,size,900,SRF,3);let x=CX-w/2;ctx.save();ctx.globalAlpha*=a;ctx.textBaseline='middle';
  for(let i=0;i<shown;i++){const ch=full[i];const isK=i>=head.length;const cw=TW(ch,size,900,SRF,3);ctx.font=`900 ${size}px ${SRF}`;ctx.textAlign='left';try{ctx.letterSpacing='3px';}catch(e){}
    if(isK){ctx.shadowColor='rgba(245,95,80,0.95)';ctx.shadowBlur=22;ctx.fillStyle=rgba(AC2,1);}else{ctx.shadowColor='rgba(0,0,0,0.6)';ctx.shadowBlur=10;ctx.fillStyle=rgba(IV,1);}ctx.fillText(ch,x,y);x+=cw;}ctx.restore();}
function tagCard(x,y,s,a,rot=0){if(a<=0.003)return;ctx.save();ctx.translate(x,y);ctx.rotate(rot);ctx.globalAlpha*=a;const w=TW(s,30,700,SRF,1)+40;ctx.fillStyle='rgba(30,12,12,0.9)';ctx.strokeStyle=rgba(AC,0.8);ctx.lineWidth=2;ctx.beginPath();ctx.roundRect(-w/2,-26,w,52,10);ctx.fill();ctx.stroke();ctx.restore();ctx.save();ctx.translate(x,y);ctx.rotate(rot);T(s,0,1,30,IV,a,700,SRF,'center',1);ctx.restore();}
function phone(x,y,s,a,glow=1){if(a<=0.003)return;ctx.save();ctx.globalCompositeOperation='lighter';const g=ctx.createRadialGradient(x,y,4,x,y,300*s);g.addColorStop(0,`rgba(255,135,115,${0.45*glow*a})`);g.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=g;ctx.fillRect(x-320*s,y-320*s,640*s,640*s);ctx.restore();
  ctx.save();ctx.translate(x,y);ctx.scale(s,s);ctx.globalAlpha*=a;ctx.fillStyle='#0b0f18';ctx.strokeStyle=rgba(AC2,0.9);ctx.lineWidth=2.5;ctx.beginPath();ctx.roundRect(-34,-62,68,124,12);ctx.fill();ctx.stroke();ctx.fillStyle=`rgba(255,190,176,${0.75*glow})`;ctx.beginPath();ctx.roundRect(-28,-54,56,108,8);ctx.fill();ctx.restore();}
// ---- beats ----
const B=[0,2.5576,5.0571,7.5567,10.0563,12.5559,HIT];// 96BPM grid bt(0,3,6,9,14)
const BLOCK=['上班','通勤','开会','家务','加班','回消息'];
function beat1(t,lt){stage(t,1);const fx=CX,fy=1180;paperMan(fx,fy,1.3,P_stand(t),1,0,t);
  BLOCK.forEach((s,i)=>{const side=i%2?1:-1,row=Math.floor(i/2);const k=eio(clamp((lt-0.15*i)/1.5));const _hd=pmHand(fx,fy,1.3,P_stand(t),side<0?0:1);const ax=_hd[0],ay=_hd[1];const bx=fx+side*lerp(230,560,k),by=lerp(430+row*120,300+row*110,k);
    line([[ax,ay],[bx,by]],2,AC,0.75);tagCard(bx,by,s,1,side*0.06+Math.sin(t*2+i)*0.03);});
  caption('白天的时间，都是','别人的',0.05,t);}
function beat2(t,lt){stage(t,0.55);const snap=clamp(lt/0.35);const fx=CX-40,fy=1180;
  if(snap<1){BLOCK.forEach((s,i)=>{const side=i%2?1:-1,row=Math.floor(i/2);tagCard(CX+side*(560+snap*200),300+row*110-snap*80,s,1-snap,side*0.06);});}
  clock(CX+250,520,120,23,59+clamp(lt*0.5),1,0,lt<0.9?'23:59':'00:00');bed(fx,fy);paperMan(fx,fy-134,1.3,P_sit(t),1,0,t,null,ss(0.6,1.0,lt));{const _ph=pmHand(fx,fy-134,1.3,P_sit(t),1);phone(_ph[0]+4,_ph[1]-26,0.5,ss(0.6,0.9,lt),1);}
  caption('深夜，终于轮到','自己',B[1]+0.05,t);}
function beat3(t,lt){stage(t,0.5);const fx=CX-140,fy=1180;const back=eio(clamp(lt/1.6));const mm=lerp(0,-50,back);clock(CX+170,500,170,0,mm+60*0,1,ss(0,0.4,lt)*(1-ss(1.5,1.8,lt)),'23:10');
  bed(fx,fy);paperMan(fx,fy-134,1.3,P_pull(t),1,0,t,null,0.2);const _h=pmHand(fx,fy-134,1.3,P_pull(t),1);const hx=_h[0],hy=_h[1];const ma=((mm/60)*6.283-1.5708);const tx=CX+170+Math.cos(ma)*136,ty=500+Math.sin(ma)*136;
  ctx.save();ctx.shadowColor='rgba(245,95,80,0.9)';ctx.shadowBlur=14;line([[hx,hy],[tx,ty]],3,AC2,0.9);ctx.restore();
  caption('于是，把时间','偷回来',B[2]+0.05,t);}
function beat4(t,lt){stage(t,0.45);const fx=CX-60,fy=1180;const k=clamp(lt/1.7);const hh=lerp(1,3,k);clock(CX+230,470,140,Math.floor(hh),(hh%1)*60,1,0,'0'+Math.floor(hh)+':'+String(Math.floor((hh%1)*60)).padStart(2,'0'));
  bed(fx,fy);paperMan(fx,fy-134,1.3,P_sit(t),1,k*0.95,t,[CX+230,470],1-k*0.6);{const _ph=pmHand(fx,fy-134,1.3,P_sit(t),1);phone(_ph[0]+4,_ph[1]-26,0.5,1-k*0.5,1-k*0.6);}caption('偷走的，是','明天',B[3]+0.05,t);}
// ---- title card ----
const QUOTES=[['再刷一个就睡',-1,340],['就五分钟',1,300],['凭什么一下班就要睡',-1,820],['这才是我的时间',1,760],['明天再说',1,980],['睡不着，也不想睡',-1,1000]];
function bubble(s,x,y,a,side){if(a<=0.003)return;const w=TW(s,30,700,SRF,1)+44;ctx.save();ctx.globalAlpha*=a;ctx.fillStyle=side<0?'rgba(56,24,26,0.92)':'rgba(160,55,50,0.9)';ctx.beginPath();ctx.roundRect(x-w/2,y-28,w,56,22);ctx.fill();ctx.beginPath();ctx.moveTo(x+side*(w/2-26),y+26);ctx.lineTo(x+side*(w/2-6),y+42);ctx.lineTo(x+side*(w/2-40),y+26);ctx.fill();ctx.restore();T(s,x,y+1,30,IV,a,700,SRF,'center',1);}
function title(t,lt){stage(t,1.1);const z=lerp(1.06,1,eo(clamp(lt/0.6)));
  ctx.save();ctx.translate(CX,520);ctx.scale(z,z);ctx.shadowColor='rgba(245,95,80,0.9)';ctx.shadowBlur=40;T('报复性熬夜',0,0,150,[248,251,255],1,900,SRF,'center',10);ctx.shadowBlur=0;ctx.restore();
  const e=ss(0.25,0.7,lt);line([[CX-430,622],[CX-300,622]],1.5,AC,e);line([[CX+300,622],[CX+430,622]],1.5,AC,e);T('REVENGE BEDTIME PROCRASTINATION',CX,622,22,AC2,e,400,LAT,'center',5);
  caption('白天没有自己，只好在深夜','抢回来',HIT+0.45,t,1,700);
  QUOTES.forEach(([s,side,y],i)=>{const a=ss(0.5+i*0.18,0.9+i*0.18,lt);const x=CX+side*(250+(i%3)*30)+Math.sin(t*0.8+i)*8;bubble(s,x,y+Math.cos(t*0.9+i)*6,a*0.95,side);});
  paperMan(CX-40,1130,0.95,P_curl(t),1,0,t,null,0.9);{const _ph=pmHand(CX-40,1130,0.95,P_curl(t),1);phone(_ph[0]+4,_ph[1]-20,0.42,1,1);}}
window.draw=function(t){ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  const scs=[[0,B[1],beat1],[B[1],B[2],beat2],[B[2],B[3],beat3],[B[3],HIT,beat4]];
  if(t<HIT){for(let i=0;i<scs.length;i++){const[a,b,fn]=scs[i];if(t>=a&&t<b){fn(t,t-a);}}
    // quick dissolve 0.15s between beats (draw next over)
    for(let i=1;i<scs.length;i++){const a=scs[i][0];if(t>=a-0.15&&t<a){ctx.save();ctx.globalAlpha=ss(a-0.15,a,t);scs[i][2](t,t-a);ctx.restore();}}}
  else title(t,t-HIT);
  // over-exposure flash into the title
  const f=Math.max(ss(HIT-0.25,HIT,t)*(t<HIT?1:0),t>=HIT?1-ss(HIT,HIT+0.45,t):0);if(f>0){ctx.fillStyle=`rgba(225,236,250,${0.92*f})`;ctx.fillRect(0,0,W,H);}
  // loop: last 0.35s dissolve back to the first frame
  const fe=ss(DUR-0.9,DUR,t);if(fe>0){ctx.fillStyle=`rgba(2,3,5,${fe})`;ctx.fillRect(0,0,W,H);}
  const ba=t<HIT?0.6:0.85;brand(W-50,H-50,22,ba,'right');};
function brand(x,y,size,a,align='right'){if(a<=0.003)return;const lab='好有趣',w=TW(lab,size,900,SRF,size*0.12),sq=size*0.5,gap=size*0.32,tw=sq+gap+w;
  const x0=align==='right'?x-tw:align==='center'?x-tw/2:x;ctx.save();ctx.globalAlpha*=a;ctx.fillStyle=rgba(AC,1);ctx.fillRect(x0,y-sq/2,sq,sq);ctx.restore();T(lab,x0+sq+gap,y,size,IV,a,900,SRF,'left',size*0.12);}
window.ready=(async()=>{for(const w of [400,700,900])await document.fonts.load(`${w} 60px ${SRF}`);await document.fonts.load(`400 30px ${LAT}`);await document.fonts.load(`700 30px ${LAT}`);await document.fonts.ready;window.draw(0);return true;})();
// ===== paper cut-out figure (overrides the particle figure) =====
const _pc=document.createElement('canvas');_pc.width=W;_pc.height=H;const pc=_pc.getContext('2d');
const _gr=(()=>{const c=document.createElement('canvas');c.width=256;c.height=256;const g=c.getContext('2d');const R=mulberry32(77);const im=g.createImageData(256,256);for(let i=0;i<im.data.length;i+=4){const v=232+R()*23;im.data[i]=v;im.data[i+1]=v-3;im.data[i+2]=v-10;im.data[i+3]=255;}g.putImageData(im,0,0);
  g.strokeStyle='rgba(150,140,120,0.10)';for(let i=0;i<60;i++){g.beginPath();const x=R()*256,y=R()*256;g.moveTo(x,y);g.lineTo(x+R()*40-20,y+R()*40-20);g.stroke();}return c;})();
const SHARDS=(()=>{const R=mulberry32(21);return Array.from({length:70},()=>[R(),R(),R(),R(),R()]);})();
function figure(x,y,s,segs,a=1,dim=0,t=0,col=IV,sink=null){if(a<=0.003)return;pc.setTransform(1,0,0,1,0,0);pc.clearRect(0,0,W,H);
  const sw=Math.sin(t*1.6)*0.012;pc.translate(x,y);pc.rotate(sw);pc.scale(s,s);pc.lineCap='round';pc.lineJoin='round';
  const drawSegs=(extra,style)=>{pc.strokeStyle=style;pc.fillStyle=style;segs.forEach(([p,q,r])=>{if(p[0]===q[0]&&p[1]===q[1]){pc.beginPath();pc.arc(p[0],p[1],r+extra,0,6.283);pc.fill();}else{pc.lineWidth=2*(r+extra);pc.beginPath();pc.moveTo(p[0],p[1]);pc.lineTo(q[0],q[1]);pc.stroke();}});};
  segs.forEach(sg=>{const one=(extra,style)=>{pc.strokeStyle=style;pc.fillStyle=style;const[p,q,r]=sg;if(p[0]===q[0]&&p[1]===q[1]){pc.beginPath();pc.arc(p[0],p[1],r+extra,0,6.283);pc.fill();}else{pc.lineWidth=2*(r+extra);pc.beginPath();pc.moveTo(p[0],p[1]);pc.lineTo(q[0],q[1]);pc.stroke();}};one(2.5,'#a39b8b');one(0,'#f2ede2');});
  // paper grain + a soft fold crease down the torso
  pc.setTransform(1,0,0,1,0,0);pc.globalCompositeOperation='source-atop';pc.globalAlpha=0.55;pc.fillStyle=pc.createPattern(_gr,'repeat');pc.fillRect(0,0,W,H);pc.globalAlpha=1;
  const sh=pc.createLinearGradient(x-80*s,0,x+80*s,0);sh.addColorStop(0,'rgba(0,0,0,0.10)');sh.addColorStop(0.5,'rgba(255,255,255,0.08)');sh.addColorStop(1,'rgba(0,0,0,0.16)');pc.fillStyle=sh;pc.fillRect(0,0,W,H);
  // tearing: erase holes where dim has eaten the paper
  if(dim>0){pc.globalCompositeOperation='destination-out';SHARDS.forEach(([u,v,w,h,r2],i)=>{if(h>=dim)return;const seg=segs[Math.floor(w*segs.length)];const[p,q,rr]=seg;const px=lerp(p[0],q[0],u)+(v-0.5)*rr,py=lerp(p[1],q[1],u)+(r2-0.5)*rr;
    pc.save();pc.translate(x+px*s,y+py*s);pc.rotate(r2*6);pc.beginPath();pc.moveTo(-18*s,-10*s);pc.lineTo(16*s,-16*s);pc.lineTo(20*s,12*s);pc.lineTo(-12*s,18*s);pc.closePath();pc.fill();pc.restore();});}
  pc.globalCompositeOperation='source-over';pc.setTransform(1,0,0,1,0,0);
  // light from the scene tints the paper a little
  ctx.save();ctx.globalAlpha*=a;ctx.shadowColor='rgba(0,0,0,0.7)';ctx.shadowBlur=26;ctx.shadowOffsetX=10;ctx.shadowOffsetY=14;ctx.drawImage(_pc,0,0);ctx.restore();
  ctx.save();ctx.globalAlpha*=a*0.05;ctx.globalCompositeOperation='lighter';ctx.drawImage(_pc,0,0);ctx.restore();
  // flying shards toward the sink
  if(dim>0&&sink){SHARDS.forEach(([u,v,w,h,r2],i)=>{if(h>=dim)return;const k=clamp((dim-h)*2.2);if(k>=1)return;const seg=segs[Math.floor(w*segs.length)];const[p,q]=seg;const sx=x+lerp(p[0],q[0],u)*s,sy=y+lerp(p[1],q[1],u)*s;
    const px=lerp(sx,sink[0],eio(k))+Math.sin(k*9+i)*30*(1-k),py=lerp(sy,sink[1],eio(k))+Math.cos(k*7+i)*20*(1-k);ctx.save();ctx.translate(px,py);ctx.rotate(k*8+r2*6);ctx.scale(1,Math.cos(k*10+i));ctx.globalAlpha=a*(1-k*0.7);ctx.fillStyle='#efe9dc';ctx.beginPath();ctx.moveTo(-10,-6);ctx.lineTo(9,-9);ctx.lineTo(11,7);ctx.lineTo(-7,10);ctx.closePath();ctx.fill();ctx.restore();});}}

function bed(fx,fy,s=1.2){const y=fy-112*s;ctx.save();ctx.fillStyle='#10141c';ctx.beginPath();ctx.roundRect(fx-260,y,560,fy-y+20,10);ctx.fill();ctx.strokeStyle=rgba(AC,0.45);ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(fx-250,y);ctx.lineTo(fx+290,y);ctx.stroke();
  ctx.fillStyle='#161b26';ctx.beginPath();ctx.roundRect(fx-250,y-46,150,50,18);ctx.fill();ctx.restore();}
