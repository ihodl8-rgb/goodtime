z=open('/home/claude/zhuge/index.html').read().split('\n')
head='\n'.join(z[:26]).replace('width="1920" height="1080"','width="1080" height="1440"').replace('const W=1920,H=1080;','const W=1080,H=1440;')
html=head+'\n'+''.join(open(f).read()+'\n' for f in ['bx.js','paperman.js','stick2.js','face_n.js','polish.js','neon_post.js','fk.js'])+'</script></body></html>'
open('index.html','w').write(html)
ss=html.replace('width="1080" height="1440"','width="2160" height="2880"').replace('const W=1080,H=1440;','const W=1080,H=1440,SS=2;').replace('ctx.setTransform(1,0,0,1,0,0)','ctx.setTransform(SS,0,0,SS,0,0)')
open('index_ss.html','w').write(ss)
