#!/bin/bash
cd $1; rm -rf keys; python3 render_ss.py keys "$2" keys 2>&1 | grep -iE "error" | head -3; ffmpeg -y -loglevel error -pattern_type glob -i 'keys/*.png' -vf scale=360:-1,tile=${3:-4x3} chk.jpg; echo KEYS_OK
